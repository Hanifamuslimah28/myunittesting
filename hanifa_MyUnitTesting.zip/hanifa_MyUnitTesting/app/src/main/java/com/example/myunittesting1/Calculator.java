package com.example.myunittesting1;

public class Calculator {

    public Integer add(Integer bil1, Integer bil2){

        return bil1+bil2;
    }
}
